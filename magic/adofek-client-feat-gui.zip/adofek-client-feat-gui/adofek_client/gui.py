import tkinter


class GUI:
    """Manage gui, forms and communicate with application_logic"""

    @staticmethod
    def create_text_message_label(text) -> tkinter.Label:
        pass

    @staticmethod
    def create_image_message_label(text) -> tkinter.Label:
        pass

    @staticmethod
    def create_file_message_label(text) -> tkinter.Label:
        pass
